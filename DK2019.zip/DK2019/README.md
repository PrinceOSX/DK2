# UPDATE TANGGAL 20 OCT 2018
------
GET TOKEN :
------
- `IOSPAD(304)`
- `8.14.2`
-
Cara Install Bot :
------
Di C9 SERVER/ VPS :
- `sudo apt-get update -y`
- `sudo apt-get install git -y`
- `sudo apt-get install python3-pip -y`
- `sudo pip3 install rsa`
- `sudo pip3 install thrift==0.11.0`
- `sudo pip3 install requests`
- `sudo pip3 install pytz`
- `sudo pip3 install bs4`
- `sudo pip3 install gtts`
- `sudo pip3 install googletrans`
- `sudo pip3 install humanfriendly`
- `sudo pip3 install goslate`
- `sudo pip3 install pafy`
- `sudo pip3 install wikipedia`
- `sudo pip3 install tweepy`
- `sudo pip3 install youtube_dl`
- `git clone https://github.com/arifistifik/2019`
- `cd 2019`
- `python prosb.py`

INSTALL Di TERMUX :
- `pkg update`
- `pkg install git`
- `pkg install python3-pip`
- `pip3 install rsa`
- `pip3 install thrift==0.11.0`
- `pip3 install requests`
- `pip3 install bs4`
- `pip3 install gtts`
- `pip3 install beautifulsoup`
- `pip3 install googletrans`
- `pip3 install pafy`
- `pip3 install humanfriendly`
- `pip3 install goslate`
- `pip3 install wikipedia`
- `pip3 install youtube_dl`
- `pip3 install tweepy`
- `git clone https://github.com/arifistifik/2019`
- `cd 2019`
- `python3 prosb.py`

Cara Menjalankan Bot Kembali :
------
Di C9 :
- `cd 2019`
- `python3 prosb.py`

Di Termux :
- `cd 2019`
- `python3 prosb.py`


EDITOR BY ARIFISTIFIK
------
- `Add My ID LINE : arifistifik`

Thx To :
------
- `SEMUANYA SEMUANYA`


